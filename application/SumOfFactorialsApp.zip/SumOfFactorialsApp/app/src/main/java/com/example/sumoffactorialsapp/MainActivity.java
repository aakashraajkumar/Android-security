package com.example.sumoffactorialsapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText numberInput = findViewById(R.id.numberInput);
        Button calculateButton = findViewById(R.id.calculateButton);
        TextView resultView = findViewById(R.id.resultView);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String inputText = numberInput.getText().toString();
                if (!inputText.isEmpty()) {
                    int number = Integer.parseInt(inputText);
                    int result = sumOfFactorials(number);
                    resultView.setText("Sum of Factorials: " + result);
                } else {
                    resultView.setText("Please enter a number");
                }
            }
        });
    }

    private int sumOfFactorials(int n) {
        int sum = 0;
        while (n > 0) {
            int f = 1;
            for (int i = n; i > 0; i--) {
                f = f * i;
            }
            sum += f;
            n--;
        }
        return sum;
    }
}
